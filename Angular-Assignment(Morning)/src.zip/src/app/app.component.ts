import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  logRecords : Array<any> = [];
  textChanged(text : any)
  {
    if(text != "" && text != "Enter text in the above Box")
    this.logRecords.push({key_up_at : new Date() ,text : text});
  }
}
