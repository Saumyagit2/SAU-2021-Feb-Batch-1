import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-logtable',
  templateUrl: './logtable.component.html',
  styleUrls: ['./logtable.component.css']
})
export class LogtableComponent implements OnInit {
  @Input('logRecords') logRecords : any;

  constructor() { }

  ngOnInit(): void {
  }

}
