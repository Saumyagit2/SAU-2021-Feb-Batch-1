import { Component,EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.css']
})
export class TextboxComponent implements OnInit {
text;
@Output('textchange') textchange = new EventEmitter<any>();
  constructor() { 
    this.text = "Enter text in the above Box";
  }

  ngOnInit(): void {
  }

  textChanged(event : any)
  {
    this.text = event.target.value;
    if(this.text === ""){
      this.text = "Enter text in the above Box";
    }
    this.textchange.emit(this.text);
  }

}
