export interface Session {
    name: string;
    instructor : string;
    description : string;
}
