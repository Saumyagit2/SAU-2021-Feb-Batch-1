export interface Session {
    sessionname: string;
    instructorname:String;
    description: string;
}