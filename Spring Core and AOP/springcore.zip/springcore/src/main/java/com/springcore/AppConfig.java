package com.springcore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.context.annotation.Bean;

public class AppConfig {
	
	@Bean(name="rectangle")
	public RectangleShape getRectangle() {
		return new RectangleShape(9,5);
	}
	
	@Bean(name="point")
	public ArrayList<RectanglePoint> getPoint() {
		ArrayList<RectanglePoint> point = new ArrayList<RectanglePoint>();
		point.add(new RectanglePoint(2,4));
		point.add(new RectanglePoint(4,7));
		point.add(new RectanglePoint(9,15));
		point.add(new RectanglePoint(5,10));
		return point;
	}
	
	@Bean(name="pointMapping")
	public Map<Integer, RectanglePoint> getpointMap() {
		Map<Integer, RectanglePoint> pointMap = new HashMap<Integer, RectanglePoint>();
		pointMap.put(1,new RectanglePoint(2,4));
		pointMap.put(3,new RectanglePoint(4,7));
		pointMap.put(2,new RectanglePoint(9,15));
		pointMap.put(4,new RectanglePoint(5,10));
		return pointMap;
	} 
	
	@Bean(name="pointsSet")
	public Set<RectanglePoint> getPointSet(){
		Set<RectanglePoint> pointSet = new HashSet<RectanglePoint>();
		pointSet.add(new RectanglePoint(2,4));
		pointSet.add(new RectanglePoint(4,7));
		pointSet.add(new RectanglePoint(9,15));
		pointSet.add(new RectanglePoint(5,10));
		return pointSet;
	}
}

