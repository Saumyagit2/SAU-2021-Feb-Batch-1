import React, { useState, useEffect } from "react";
import { Text, TouchableOpacity,TextInput, View, StyleSheet, Button, AsyncStorage } from "react-native";

const Login = ({ navigation }) => {
    const [username, setUserName] = useState("");
    const [err,setErr]=useState("")
    useEffect(() => {
        checkAuth()
    }, [])

    const checkAuth = async () => {
        const userName = await AsyncStorage.getItem("username");
        if (userName) {
            navigation.navigate("Add Note");
        }
        return;
    }

    const login = async () => {
        if(!username){
        notifyMessage("Invalid User Name");
        return;
    }
    navigation.navigate("Add Note");
};
    return (
        <View style={Styles.container}>
            <Text style={Styles.loginTextStyle}>Login</Text>
            <TextInput style={Styles.textInputStyle} onChangeText={(text) => setUserName(text)} placeholder="Please enter your username..." />
            <Text style={Styles.err}>{err}</Text>
            <TouchableOpacity onPress={login}>
            <Text style={Styles.loginBtn}>Login</Text>
            </TouchableOpacity>
        </View>
    )
}


const Styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#FFC0CB",
        justifyContent: "center",
        alignItems: "center"
    },
    loginTextStyle: {
        fontSize: 25,
        fontWeight: "700",
        marginVertical: 20,
        borderRadius: 30

    },
    textInputStyle: {
        borderColor: "black",
        borderWidth: 1,
        borderRadius: 5,
        fontSize: 20,
        padding: 5,
        width: "60%",
        marginBottom: 20
    },
    loginBtn: {
        width: 250,
        fontSize:20,
        borderRadius: 25,
        height: 50,
        textAlign:"center",
        alignItems: "center",
        justifyContent: "center",
        marginTop: 40,
        backgroundColor: "#FF1493",
      },
      err:
      {
          color:"red"
      }
});

export default Login;
