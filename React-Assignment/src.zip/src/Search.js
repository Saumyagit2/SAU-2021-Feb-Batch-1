import React, {Component} from 'react';
import Panel from 'react-bootstrap/lib/Panel'
import Button from 'react-bootstrap/lib/Button'
import BooksDetails from './BooksDetails'

import axios from 'axios'

export default class Books extends Component {

  constructor(props) {
    super(props)
    this.state = {
      selectedbook: 0,
      
    }
  }

  //function which is called the first time the component loads
 componentDidMount() {
   this.getBookData();
  }

  //Function to get the Book Data from json
  getBookData() {
    axios.get('assets/samplejson/booklist.json').then(response => {
      this.setState({bookList: response});

    })
  };

  searchdata = (idToSearch)=> {
    return this.state.bookList.data.filter(item => {
    return item.name === idToSearch
})
};

  

  myChangeHandler = (event) => {
    let nam = event.target.name;
    let val = event.target.value;
    //this.setState({[nam]: val});

    this.setState({url: val});

    let result = this.searchdata(val)
    this.setState({temp:result[0].id})
    
  }

  render() {
    if (!this.state.bookList)
      return (<p>Loading data</p>)
    return (

            <form onSubmit={this.mySubmitHandler}>

             <input
               type='text'
               name='url'
               onChange={this.myChangeHandler}
             />
             <br/>
             <br/>

             <Button bsStyle="info" onClick={() => this.setState({selectedbook: this.state.temp})}>

               Click to View Details

             </Button>


           </form>

)
  

}

}
