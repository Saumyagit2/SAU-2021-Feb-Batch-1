import React, {Component} from 'react';
import Panel from 'react-bootstrap/lib/Panel'
import axios from 'axios'

//This Component is a child Component of Books Component
export default class BooksDetails extends Component {

  constructor(props) {
    super(props);
    this.state = {}
  }

 

  //Function which is called whenver the component is updated
  componentDidUpdate(prevProps) {

    //get Books Details only if props has changed
    if (this.props.val !== prevProps.val) {
      this.getBooksDetails(this.props.val)
    }
  }

  //Function to Load the booksdetails data from json.
  getBooksDetails(id) {
    axios.get('assets/samplejson/book' + id + '.json').then(response => {
      this.setState({bookDetails: response})
    })
  };

  render() {
    if (!this.state.bookDetails)
      return (<p>Loading Data</p>)
    return (<div className="bookdetails">
      <Panel bsStyle="info" className="centeralign">
        <Panel.Heading>
          <Panel.Title componentClass="h3">{this.state.bookDetails.data.name}</Panel.Title>
        </Panel.Heading>
        <Panel.Body>
          <p>Name : {this.state.bookDetails.data.name}</p>
          <p>Author : {this.state.bookDetails.data.author}</p>
          <p>Publisher : {this.state.bookDetails.data.publisher}</p>
          <p>Description : {this.state.bookDetails.data.description}</p>
          
        </Panel.Body>
      </Panel>
    </div>)
  }
}
