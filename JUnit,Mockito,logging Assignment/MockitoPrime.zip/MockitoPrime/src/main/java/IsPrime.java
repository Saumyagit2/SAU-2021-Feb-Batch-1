public interface IsPrime {
    public boolean check(int num);
}