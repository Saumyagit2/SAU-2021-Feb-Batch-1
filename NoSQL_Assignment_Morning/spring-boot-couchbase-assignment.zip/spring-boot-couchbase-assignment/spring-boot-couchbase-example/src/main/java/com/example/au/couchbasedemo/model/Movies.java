package com.example.au.couchbasedemo.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import com.sun.istack.NotNull;

@Document
public class Movies {
    
    @Id
    String id;
    
    @NotNull
    @Field
    String movieName;
    
    @NotNull
    @Field
    List<String> city;
 

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public List<String> getCity() {
		return city;
	}

	public void setCity(List<String> city) {
		this.city = city;
	}
	
	

	public String getId() {
		return id;
	}

	public Movies(String id, String movieName, List<String> city) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.city = city;
		
	}
}
